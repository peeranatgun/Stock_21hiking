// env.js — Inject environment variables from Vercel
// In Vercel, set SUPABASE_URL and SUPABASE_ANON_KEY as Environment Variables
// Then reference them here via a build step or directly replace below.
// For a purely static Vercel deploy (no build), manually paste your values here.

window.__ENV__ = {
  SUPABASE_URL: 'YOUR_SUPABASE_URL',       // replace with your project URL
  SUPABASE_ANON_KEY: 'YOUR_SUPABASE_ANON_KEY', // replace with your anon key
};
